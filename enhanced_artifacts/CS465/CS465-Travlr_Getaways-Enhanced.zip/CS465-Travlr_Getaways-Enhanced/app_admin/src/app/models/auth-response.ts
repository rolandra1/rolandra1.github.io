// Model to hold JWT authentication token
export class AuthResponse {
    token: string;

    constructor() {
        this.token = '';
    }
}

export class AuthResponse {
}

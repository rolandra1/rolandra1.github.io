package com.example.cs360p2wt_amos_roland;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.example.cs360p2wt_amos_roland.FirebaseManager;

public class SetGoalActivity extends AppCompatActivity {
    private EditText goalWeightInput;
    private Button saveGoalButton;
    private DatabaseHelper databaseHelper;
    private String loggedInUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_goal);

        goalWeightInput = findViewById(R.id.goalWeightInput);
        saveGoalButton = findViewById(R.id.saveGoalButton);
        databaseHelper = new DatabaseHelper(this);

        loggedInUsername = getIntent().getStringExtra("USERNAME");
        Log.d("SetGoalActivity", "Username received: " + loggedInUsername);

        saveGoalButton.setOnClickListener(v -> {
            String goalWeightStr = goalWeightInput.getText().toString().trim();

            if (!goalWeightStr.isEmpty()) {
                try {
                    double goalWeight = Double.parseDouble(goalWeightStr);
                    if (loggedInUsername != null) {
                        databaseHelper.setGoalWeight(loggedInUsername, goalWeight);

                        // Sync goal weight to Firebase
                        DatabaseReference profileRef = FirebaseManager.getUserProfileRef(loggedInUsername);
                        if (profileRef != null) {
                            profileRef.child("goalWeight").setValue(goalWeight);
                        }

                        Toast.makeText(this, "Goal Weight Set!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(SetGoalActivity.this, AddWeightActivity.class);
                        intent.putExtra("USERNAME", loggedInUsername);
                        Log.d("SetGoalActivity", "Username being passed: " + loggedInUsername);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "Username not found!", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Enter a valid weight!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a goal weight!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

package com.example.cs360p2wt_amos_roland;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView welcomeText;
    private Button goToSetGoalButton, goToAddWeightButton, goToWeightTrackingButton, goToSmsNotificationButton, logoutButton;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the username from the intent
        username = getIntent().getStringExtra("USERNAME");
        Log.d("MainActivity", "Username received: " + username);

        welcomeText = findViewById(R.id.welcomeText);
        goToSetGoalButton = findViewById(R.id.goToSetGoalButton);
        goToAddWeightButton = findViewById(R.id.goToAddWeightButton);
        goToWeightTrackingButton = findViewById(R.id.goToWeightTrackingButton);
        goToSmsNotificationButton = findViewById(R.id.goToSmsNotificationButton);
        logoutButton = findViewById(R.id.logoutButton);

        // Set the welcome message
        if (username != null && !username.isEmpty()) {
            welcomeText.setText("Welcome: " + username);
        } else {
            welcomeText.setText("Welcome");
        }

        goToSetGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SetGoalActivity.class);
            intent.putExtra("USERNAME", username);
            Log.d("MainActivity", "Username being passed: " + username);
            startActivity(intent);
        });

        goToAddWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddWeightActivity.class);
            intent.putExtra("USERNAME", username);
            Log.d("MainActivity", "Username being passed: " + username);
            startActivity(intent);
        });

        goToWeightTrackingButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, WeightTrackingActivity.class);
            intent.putExtra("USERNAME", username);
            Log.d("MainActivity", "Username being passed: " + username);
            startActivity(intent);
        });

        goToSmsNotificationButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SmsNotificationActivity.class);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}

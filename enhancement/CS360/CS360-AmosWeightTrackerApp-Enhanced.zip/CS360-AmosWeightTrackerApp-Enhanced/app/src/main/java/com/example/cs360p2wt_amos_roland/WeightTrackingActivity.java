package com.example.cs360p2wt_amos_roland;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DatabaseReference;
import com.example.cs360p2wt_amos_roland.FirebaseManager;

import java.io.File;
import java.util.List;

/**
 * WeightTrackingActivity
 *
 * Main tracking screen that:
 *  - Shows the current user and encrypted goal weight
 *  - Loads encrypted weight entries from SQLite and displays them in a table
 *  - Lets the user open a detailed history view
 *  - Lets the user export a CSV backup of their data
 *  - Can trigger an SMS notification when they reach their goal weight
 *
 * This class is a key part of my CS-499 database enhancement because it:
 *  - Reads encrypted data through DatabaseHelper
 *  - Displays structured history (date / weight)
 *  - Provides a simple backup/export feature for the user
 */
public class WeightTrackingActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private TextView userNameTextView;
    private TextView goalWeightTextView;
    private TableLayout weightTable;

    private Button viewHistoryButton;
    private Button exportDataButton;
    private Button addWeightButton;

    private DatabaseHelper dbHelper;
    private String username;
    private double goalWeight = 0.0;

    // Holds the current history list (with IDs) so CRUD can work on it
    private List<DatabaseHelper.WeightEntry> currentHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        dbHelper = new DatabaseHelper(this);

        // Username is passed from Login/Main screens
        username = getIntent().getStringExtra("USERNAME");

        // Bind UI elements from XML
        userNameTextView = findViewById(R.id.userNameTextView);
        goalWeightTextView = findViewById(R.id.goalWeightTextView);
        weightTable = findViewById(R.id.weightTable);

        addWeightButton = findViewById(R.id.addWeightButton);
        viewHistoryButton = findViewById(R.id.viewHistoryButton);
        exportDataButton = findViewById(R.id.exportDataButton);

        // Show the current user
        userNameTextView.setText(username != null ? "User: " + username : "User: Guest");

        // Load goal and history from encrypted SQLite database
        loadUserData();
        loadWeightData();

        // Go back to previous screen where the user can add a new entry
        addWeightButton.setOnClickListener(v -> finish());

        // Open the detailed history screen (HistoryActivity)
        viewHistoryButton.setOnClickListener(v -> {
            if (username == null || username.isEmpty()) {
                Toast.makeText(this, "No user found for history", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(WeightTrackingActivity.this, HistoryActivity.class);
            intent.putExtra("USERNAME", username);
            startActivity(intent);
        });

        // Export user data (user record + full weight history) as CSV
        exportDataButton.setOnClickListener(v -> {
            if (username == null || username.isEmpty()) {
                Toast.makeText(this, "No user data to export", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                File outputDir = getExternalFilesDir(null);
                File csvFile = dbHelper.exportUserDataToCsv(username, outputDir);
                if (csvFile != null) {
                    String message = "Backup saved to:\n" + csvFile.getAbsolutePath();
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "No data found to export", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Failed to export data", Toast.LENGTH_LONG).show();
            }
        });

        // Request SMS permission one time so the app can send goal notifications
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    /**
     * Load the username and decrypted goal weight from the database.
     * If the goal is not set, show a default message.
     */
    private void loadUserData() {
        Double goal = dbHelper.getGoalWeight(username);
        if (goal != null) {
            goalWeight = goal;
            goalWeightTextView.setText("Goal Weight: " + goalWeight + " lbs");
        } else {
            goalWeightTextView.setText("Goal Weight: Not Set");
        }
    }

    /**
     * Load decrypted weight history and render it as a two-column table:
     * Date | Weight (lbs).
     * Attach long-press listeners to each row for CRUD.
     */
    private void loadWeightData() {
        // Keep header row (index 0) and divider (index 1), remove everything below
        if (weightTable.getChildCount() > 2) {
            weightTable.removeViews(2, weightTable.getChildCount() - 2);
        }

        currentHistory = dbHelper.getWeightHistory(username);

        if (currentHistory.isEmpty()) {
            // No data yet; table header still shows, which is fine
            return;
        }

        for (DatabaseHelper.WeightEntry entry : currentHistory) {
            TableRow row = new TableRow(this);
            row.setPadding(0, 8, 0, 8);

            TextView dateText = new TextView(this);
            dateText.setText(entry.date);
            dateText.setTextSize(16);
            dateText.setLayoutParams(
                    new TableRow.LayoutParams(
                            0,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1f
                    )
            );

            TextView weightText = new TextView(this);
            weightText.setText(String.valueOf(entry.weight));
            weightText.setTextSize(16);
            weightText.setLayoutParams(
                    new TableRow.LayoutParams(
                            0,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1f
                    )
            );

            row.addView(dateText);
            row.addView(weightText);

            // Enable long-press CRUD for this row
            row.setOnLongClickListener(v -> {
                showRowOptionsDialog(entry);
                return true;
            });

            weightTable.addView(row);
        }
    }

    /**
     * Show a small dialog when user long-presses a row:
     * Edit | Delete | Cancel
     */
    private void showRowOptionsDialog(DatabaseHelper.WeightEntry entry) {
        CharSequence[] options = {"Edit", "Delete", "Cancel"};

        new AlertDialog.Builder(this)
                .setTitle("Entry on " + entry.date)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        showEditDialog(entry);
                    } else if (which == 1) {
                        confirmDelete(entry);
                    } else {
                        dialog.dismiss();
                    }
                })
                .show();
    }

    /**
     * Dialog to edit the selected weight entry.
     */
    private void showEditDialog(DatabaseHelper.WeightEntry entry) {
        final EditText inputWeight = new EditText(this);
        inputWeight.setHint("Enter new weight (lbs)");
        inputWeight.setText(String.valueOf(entry.weight));

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(inputWeight)
                .setPositiveButton("Update", (dialog, which) -> {
                    String newWeightStr = inputWeight.getText().toString().trim();
                    if (newWeightStr.isEmpty()) {
                        Toast.makeText(this, "Weight cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double newWeight = Double.parseDouble(newWeightStr);
                        boolean ok = dbHelper.updateWeightEntry(entry.id, newWeight);
                        if (ok) {
                            // Sync updated weight to Firebase
                            DatabaseReference weightRef = FirebaseManager.getUserWeightsRef(username);
                            if (weightRef != null) {
                                weightRef.child(entry.date).child("weight").setValue(newWeight);
                            }

                            Toast.makeText(this, "Weight updated.", Toast.LENGTH_SHORT).show();
                            loadWeightData();
                            checkGoalAchievement(newWeight);
                        } else {
                            Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    /**
     * Confirm deletion of the selected entry.
     */
    private void confirmDelete(DatabaseHelper.WeightEntry entry) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage("Delete weight on " + entry.date + " (" + entry.weight + " lbs)?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    boolean ok = dbHelper.deleteWeightEntry(entry.id);
                    if (ok) {
                        // Remove this entry from Firebase as well
                        DatabaseReference weightRef = FirebaseManager.getUserWeightsRef(username);
                        if (weightRef != null) {
                            weightRef.child(entry.date).removeValue();
                        }

                        Toast.makeText(this, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
                        loadWeightData();
                    } else {
                        Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    /**
     * Check if the user reached or passed their goal weight.
     * You can call this after inserting or updating a weight entry.
     */
    private void checkGoalAchievement(double weight) {
        if (goalWeight > 0 && weight <= goalWeight) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSMS();
            } else {
                Toast.makeText(
                        this,
                        "Goal reached. SMS permission not granted.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    /**
     * Send a simple SMS alert when the goal weight is reached.
     * In a real app, the phone number would be configured by the user.
     */
    private void sendGoalReachedSMS() {
        String phoneNumber = "1234567890";  // placeholder for user-configured number
        String message = "Congratulations. You have reached your goal weight.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached. SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_LONG).show();
        }
    }

    // Permission callback for SMS
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

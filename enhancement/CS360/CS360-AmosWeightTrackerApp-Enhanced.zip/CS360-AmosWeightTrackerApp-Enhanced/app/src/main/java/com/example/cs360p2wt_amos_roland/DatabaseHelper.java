package com.example.cs360p2wt_amos_roland;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    // Bump version so schema updates (goal and weight now stored as TEXT with encryption)
    private static final int DATABASE_VERSION = 5;

    // Table names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHTS = "weights";

    // Common column names
    private static final String COLUMN_ID = "id";

    // Users table column names
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    // Weights table column names
    private static final String COLUMN_DATE = "date";      // stored as yyyy-MM-dd
    private static final String COLUMN_WEIGHT = "weight";

    // Simple AES settings for this course project
    // In a real app these would not be hardcoded
    private static final String ENCRYPTION_KEY = "A1b2C3d4E5f6G7h8"; // 16 chars
    private static final String ENCRYPTION_IV  = "1H2g3J4k5L6m7N8";  // 16 chars

    // Small helper model class for weight history
    public static class WeightEntry {
        public final int id;
        public final String date;      // yyyy-MM-dd
        public final double weight;

        public WeightEntry(int id, String date, double weight) {
            this.id = id;
            this.date = date;
            this.weight = weight;
        }
    }


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users: goal_weight stored as TEXT (encrypted)
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT,"
                + COLUMN_GOAL_WEIGHT + " TEXT"
                + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Weights: weight stored as TEXT (encrypted)
        String CREATE_WEIGHTS_TABLE = "CREATE TABLE " + TABLE_WEIGHTS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_WEIGHT + " TEXT"
                + ")";
        db.execSQL(CREATE_WEIGHTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For this project, a simple drop and recreate is acceptable
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For this course project we can safely drop and recreate on downgrade too.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }


    // -------------------------------------------------------------------------
    // Encryption helpers
    // -------------------------------------------------------------------------

    private String encrypt(String plainText) {
        if (plainText == null) return null;
        try {
            IvParameterSpec iv = new IvParameterSpec(ENCRYPTION_IV.getBytes());
            SecretKeySpec keySpec = new SecretKeySpec(ENCRYPTION_KEY.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, iv);
            byte[] encrypted = cipher.doFinal(plainText.getBytes());
            return Base64.encodeToString(encrypted, Base64.NO_WRAP);
        } catch (Exception e) {
            // If encryption fails, fall back to plain text to avoid crashes
            return plainText;
        }
    }

    private String decrypt(String cipherText) {
        if (cipherText == null) return null;
        try {
            IvParameterSpec iv = new IvParameterSpec(ENCRYPTION_IV.getBytes());
            SecretKeySpec keySpec = new SecretKeySpec(ENCRYPTION_KEY.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, iv);
            byte[] decoded = Base64.decode(cipherText, Base64.NO_WRAP);
            byte[] original = cipher.doFinal(decoded);
            return new String(original);
        } catch (Exception e) {
            // If decryption fails, just return the raw string
            return cipherText;
        }
    }

    // -------------------------------------------------------------------------
    // Password hashing
    // -------------------------------------------------------------------------

    private String hashPassword(String plainPassword) {
        if (plainPassword == null) {
            return null;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(plainPassword.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    sb.append('0');
                }
                sb.append(hex);
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // Fallback to plain text if hashing fails to avoid crashes
            return plainPassword;
        }
    }

    // -------------------------------------------------------------------------
    // USER METHODS
    // -------------------------------------------------------------------------

    // Register a new user with hashed password
    public boolean registerUser(String username, String password) {
        String hashedPassword = hashPassword(password);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, hashedPassword);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Alias for compatibility with older code
    public boolean addUser(String username, String password) {
        return registerUser(username, password);
    }

    // Check login using hashed password
    public boolean checkUser(String username, String password) {
        String hashedPassword = hashPassword(password);

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, hashedPassword}
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();
        return exists;
    }

    // Check if username is taken
    public boolean isUsernameTaken(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(
                    "SELECT " + COLUMN_ID + " FROM " + TABLE_USERS +
                            " WHERE " + COLUMN_USERNAME + " = ?",
                    new String[]{username}
            );
            return cursor.getCount() > 0;
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Get user id, or -1 if not found
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_ID + " FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ?",
                new String[]{username}
        );

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return userId;
    }

    // Store encrypted goal weight as TEXT
    public void setGoalWeight(String username, double weight) {
        String encryptedGoal = encrypt(String.valueOf(weight));

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, encryptedGoal);
        db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username});
        db.close();
    }

    // Retrieve decrypted goal weight (or null if not set)
    public Double getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ?",
                new String[]{username}
        );

        Double goal = null;
        if (cursor.moveToFirst()) {
            String encrypted = cursor.getString(0);
            if (encrypted != null) {
                String decrypted = decrypt(encrypted);
                try {
                    goal = Double.parseDouble(decrypted);
                } catch (NumberFormatException e) {
                    goal = null;
                }
            }
        }
        cursor.close();
        db.close();
        return goal;
    }

    // -------------------------------------------------------------------------
    // WEIGHT METHODS
    // -------------------------------------------------------------------------

    // Insert a weight entry using today's date
    public boolean addWeightEntry(String username, double weight) {
        return insertWeightEntry(username, getCurrentDate(), weight);
    }

    // Insert a weight entry with a specific date (value encrypted as TEXT)
    public boolean insertWeightEntry(String username, String date, double weight) {
        String encryptedWeight = encrypt(String.valueOf(weight));

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_DATE, date);
        contentValues.put(COLUMN_WEIGHT, encryptedWeight);

        long result = db.insert(TABLE_WEIGHTS, null, contentValues);
        db.close();
        return result != -1;
    }

    // Update a single weight entry by id, keeping weight encrypted
    public boolean updateWeightEntry(int id, double newWeight) {
        String encryptedWeight = encrypt(String.valueOf(newWeight));
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, encryptedWeight);
        int rows = db.update(TABLE_WEIGHTS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // Delete a single weight entry by id
    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // Get full weight history decrypted
    public List<WeightEntry> getWeightHistory(String username) {
        List<WeightEntry> history = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_ID + ", " + COLUMN_DATE + ", " + COLUMN_WEIGHT +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COLUMN_USERNAME + " = ?" +
                        " ORDER BY " + COLUMN_DATE + " ASC",
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                String encrypted = cursor.getString(2);
                String decrypted = decrypt(encrypted);
                double weight;
                try {
                    weight = Double.parseDouble(decrypted);
                } catch (NumberFormatException e) {
                    // Skip malformed entries
                    continue;
                }
                history.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return history;
    }

    // Optional: history between dates
    public List<WeightEntry> getWeightHistoryBetweenDates(
            String username,
            String startDate,
            String endDate
    ) {
        List<WeightEntry> history = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_ID + ", " + COLUMN_DATE + ", " + COLUMN_WEIGHT +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COLUMN_USERNAME + " = ?" +
                        " AND " + COLUMN_DATE + " >= ?" +
                        " AND " + COLUMN_DATE + " <= ?" +
                        " ORDER BY " + COLUMN_DATE + " ASC",
                new String[]{username, startDate, endDate}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                String encrypted = cursor.getString(2);
                String decrypted = decrypt(encrypted);

                double weight;
                try {
                    weight = Double.parseDouble(decrypted);
                } catch (NumberFormatException e) {
                    // Skip malformed rows
                    continue;
                }

                history.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return history;
    }

    // -------------------------------------------------------------------------
    // DATE HELPER
    // -------------------------------------------------------------------------

    private String getCurrentDate() {
        SimpleDateFormat dateFormat =
                new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    // -------------------------------------------------------------------------
    // EXPORT / BACKUP
    // -------------------------------------------------------------------------

    // Return CSV text for user info and history
    public String exportUserDataToCsv(String username) {
        StringBuilder sb = new StringBuilder();

        SQLiteDatabase db = this.getReadableDatabase();

        // User info
        sb.append("User Information\n");
        sb.append("username,goal_weight\n");

        Cursor userCursor = db.rawQuery(
                "SELECT " + COLUMN_USERNAME + ", " + COLUMN_GOAL_WEIGHT +
                        " FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ?",
                new String[]{username}
        );

        if (userCursor.moveToFirst()) {
            String uName = userCursor.getString(0);
            String encryptedGoal = userCursor.getString(1);
            String decryptedGoal = decrypt(encryptedGoal);
            double goal = 0.0;
            try {
                goal = Double.parseDouble(decryptedGoal);
            } catch (Exception ignored) {
            }
            sb.append(uName).append(",").append(goal).append("\n");
        }
        userCursor.close();

        // Weight history
        sb.append("\nWeight History\n");
        sb.append("date,weight\n");

        Cursor weightCursor = db.rawQuery(
                "SELECT " + COLUMN_DATE + ", " + COLUMN_WEIGHT +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COLUMN_USERNAME + " = ?" +
                        " ORDER BY " + COLUMN_DATE + " ASC",
                new String[]{username}
        );

        if (weightCursor.moveToFirst()) {
            do {
                String date = weightCursor.getString(0);
                String encrypted = weightCursor.getString(1);
                String decrypted = decrypt(encrypted);
                sb.append(date).append(",").append(decrypted).append("\n");
            } while (weightCursor.moveToNext());
        }
        weightCursor.close();
        db.close();

        return sb.toString();
    }

    // Save CSV to a file in a directory and return the File
    public File exportUserDataToCsv(String username, File directory) {
        if (directory == null) return null;

        String csvData = exportUserDataToCsv(username);

        File outputFile = new File(directory, username + "_weight_backup.csv");

        FileWriter writer = null;
        try {
            writer = new FileWriter(outputFile);
            writer.write(csvData);
            writer.flush();
            return outputFile;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ignored) {
                }
            }
        }
    }
}

package com.example.cs360p2wt_amos_roland;

import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.List;

/**
 * HistoryActivity
 *
 * This screen reads the encrypted weight history from DatabaseHelper,
 * converts it into a human readable table, and shows a summary.
 *
 * It also draws a simple line chart so the user can visually
 * see the trend of weight over time. This supports my CS 499
 * enhancement narrative about using stored history data for analytics.
 */
public class HistoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private String username;

    private TextView historyTitleTextView;
    private TextView historySummaryTextView;
    private TableLayout historyTable;
    private LineChart weightProgressChart;

    private List<DatabaseHelper.WeightEntry> historyEntries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        dbHelper = new DatabaseHelper(this);

        // Get username from intent
        username = getIntent().getStringExtra("USERNAME");

        historyTitleTextView = findViewById(R.id.historyTitleTextView);
        historySummaryTextView = findViewById(R.id.historySummaryTextView);
        historyTable = findViewById(R.id.historyTable);
        weightProgressChart = findViewById(R.id.weightProgressChart);

        if (username != null && !username.isEmpty()) {
            historyTitleTextView.setText("Weight Progress for " + username);
        } else {
            historyTitleTextView.setText("Weight History");
        }

        loadHistory();
    }

    /**
     * Load weight history for this user, update chart, table, and summary.
     */
    private void loadHistory() {
        historyEntries = dbHelper.getWeightHistory(username);

        if (historyEntries == null || historyEntries.isEmpty()) {
            historySummaryTextView.setText("No weight entries recorded yet.");

            // Clear any old rows but keep header + divider
            if (historyTable.getChildCount() > 2) {
                historyTable.removeViews(2, historyTable.getChildCount() - 2);
            }

            // Show message on chart as well
            weightProgressChart.setNoDataText("No weight history available yet.");
            weightProgressChart.clear();
            return;
        }

        // Remove any existing data rows (keep header row at index 0 and divider at index 1)
        if (historyTable.getChildCount() > 2) {
            historyTable.removeViews(2, historyTable.getChildCount() - 2);
        }

        double first = historyEntries.get(0).weight;
        double last = historyEntries.get(historyEntries.size() - 1).weight;

        // Add a row for each history entry in the table
        for (DatabaseHelper.WeightEntry entry : historyEntries) {
            TableRow row = new TableRow(this);
            row.setPadding(0, 8, 0, 8);

            TextView dateText = new TextView(this);
            dateText.setText(entry.date);
            dateText.setTextSize(16);
            dateText.setLayoutParams(
                    new TableRow.LayoutParams(
                            0,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1f
                    )
            );

            TextView weightText = new TextView(this);
            weightText.setText(String.valueOf(entry.weight));
            weightText.setTextSize(16);
            weightText.setLayoutParams(
                    new TableRow.LayoutParams(
                            0,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1f
                    )
            );

            row.addView(dateText);
            row.addView(weightText);

            historyTable.addView(row);
        }

        // Summary line to help explain the trend in the narrative
        String trendText;
        if (last < first) {
            trendText = "Overall trend: weight decreased from " + first + " to " + last + " lbs.";
        } else if (last > first) {
            trendText = "Overall trend: weight increased from " + first + " to " + last + " lbs.";
        } else {
            trendText = "Overall trend: weight stayed the same at " + last + " lbs.";
        }

        historySummaryTextView.setText(
                "Total entries: " + historyEntries.size() + "\n" + trendText
        );

        // After table and summary are ready, draw the chart
        setupChart();
    }

    /**
     * Build a line chart of weight values over time.
     * X axis uses the index mapped to date labels.
     */
    private void setupChart() {
        if (historyEntries == null || historyEntries.isEmpty()) {
            weightProgressChart.setNoDataText("No weight history available yet.");
            weightProgressChart.clear();
            return;
        }

        List<Entry> entries = new ArrayList<>();
        final List<String> dateLabels = new ArrayList<>();

        // Use the position in the list as X and weight as Y
        for (int i = 0; i < historyEntries.size(); i++) {
            DatabaseHelper.WeightEntry item = historyEntries.get(i);
            entries.add(new Entry(i, (float) item.weight));
            dateLabels.add(item.date);
        }

        LineDataSet dataSet = new LineDataSet(entries, "Weight (lbs)");

        /* ---- Thick Blue Line ---- */
        dataSet.setColor(0xFF1565C0);       // Strong blue line (#1565C0)
        dataSet.setCircleColor(0xFF1565C0); // Blue data points
        dataSet.setLineWidth(4f);           // THICK line
        dataSet.setCircleRadius(4f);        // Slightly larger dots
        dataSet.setValueTextSize(10f);


        LineData lineData = new LineData(dataSet);
        weightProgressChart.setData(lineData);

        // Format X axis to show dates from our label list
        XAxis xAxis = weightProgressChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setLabelRotationAngle(-45f);

        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                if (index >= 0 && index < dateLabels.size()) {
                    return dateLabels.get(index);
                } else {
                    return "";
                }
            }
        });

        // Use only the left axis and hide the description text
        weightProgressChart.getAxisRight().setEnabled(false);
        weightProgressChart.getDescription().setEnabled(false);
        weightProgressChart.setExtraBottomOffset(16f);

        weightProgressChart.invalidate(); // Refresh the chart with new data
    }
}

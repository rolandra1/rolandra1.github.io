package com.example.cs360p2wt_amos_roland;

public class WeightEntry {

    public String id;
    public String encryptedWeight;
    public String dateIso;
    public String note;

    public WeightEntry() {
        // Needed for Firebase
    }

    public WeightEntry(String id, String encryptedWeight, String dateIso, String note) {
        this.id = id;
        this.encryptedWeight = encryptedWeight;
        this.dateIso = dateIso;
        this.note = note;
    }
}

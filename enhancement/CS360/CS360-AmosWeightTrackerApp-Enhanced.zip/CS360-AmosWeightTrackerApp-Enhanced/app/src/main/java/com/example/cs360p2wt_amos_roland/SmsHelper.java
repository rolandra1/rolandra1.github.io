package com.example.cs360p2wt_amos_roland;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsHelper {
    private static final int SMS_PERMISSION_CODE = 101;

    public static boolean checkSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestSmsPermission(Activity activity) {
        if (!checkSmsPermission(activity)) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    public static void sendSms(Context context, String phoneNumber, String message) {
        if (checkSmsPermission(context)) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(context, "📩 SMS Sent Successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(context, "⚠️ SMS Failed to Send!", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(context, "❌ SMS Permission Not Granted!", Toast.LENGTH_LONG).show();
        }
    }
}

package com.example.cs360p2wt_amos_roland;

import androidx.annotation.NonNull;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseManager {

    private static final String USERS_NODE = "users";
    private static final String WEIGHTS_NODE = "weights";
    private static final String PROFILE_NODE = "profile";

    private static DatabaseReference getRootRef() {
        return FirebaseDatabase.getInstance().getReference();
    }

    // weights node for a given username
    public static DatabaseReference getUserWeightsRef(@NonNull String username) {
        return getRootRef()
                .child(USERS_NODE)
                .child(username)
                .child(WEIGHTS_NODE);
    }

    // profile node (for goal weight and other info) for a given username
    public static DatabaseReference getUserProfileRef(@NonNull String username) {
        return getRootRef()
                .child(USERS_NODE)
                .child(username)
                .child(PROFILE_NODE);
    }
}

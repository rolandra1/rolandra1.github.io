package com.example.cs360p2wt_amos_roland;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {
    private EditText weightInput, dateInput;
    private Button saveWeightButton, viewWeightListButton;
    private DatabaseHelper databaseHelper;
    private String loggedInUsername;
    private Calendar myCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);
        saveWeightButton = findViewById(R.id.saveWeightButton);
        viewWeightListButton = findViewById(R.id.viewWeightListButton);
        databaseHelper = new DatabaseHelper(this);
        myCalendar = Calendar.getInstance();

        loggedInUsername = getIntent().getStringExtra("USERNAME");

        // Set up the DatePicker
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDateLabel();
            }
        };

        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddWeightActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        saveWeightButton.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString().trim();
            String dateStr = dateInput.getText().toString().trim();

            if (!weightStr.isEmpty() && !dateStr.isEmpty()) {
                try {
                    double weight = Double.parseDouble(weightStr);

                    boolean insertSuccess = databaseHelper.insertWeightEntry(loggedInUsername, dateStr, weight);
                    if (insertSuccess) {
                        Toast.makeText(this, "Weight Entry Saved!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to Save Entry!", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Enter a valid weight!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
            }
        });

        viewWeightListButton.setOnClickListener(v -> {
            Intent intent = new Intent(AddWeightActivity.this, WeightTrackingActivity.class);
            intent.putExtra("USERNAME", loggedInUsername);
            startActivity(intent);
        });
    }

    private void updateDateLabel() {
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        dateInput.setText(sdf.format(myCalendar.getTime()));
    }
}
package com.example.cs360p2wt_amos_roland;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class WeightTrackingActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;
    private ListView weightListView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> weightList;
    private ArrayList<Integer> entryIds;
    private DatabaseHelper dbHelper;
    private int selectedItemId = -1;
    private TextView userNameTextView, goalWeightTextView;
    private double goalWeight = 0;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);

        // Get the username from the intent
        username = getIntent().getStringExtra("USERNAME");

        weightListView = findViewById(R.id.weightListView);
        userNameTextView = findViewById(R.id.userNameTextView);
        goalWeightTextView = findViewById(R.id.goalWeightTextView);
        Button addWeightButton = findViewById(R.id.addWeightButton);

        weightList = new ArrayList<>();
        entryIds = new ArrayList<>();
        dbHelper = new DatabaseHelper(this);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightList);
        weightListView.setAdapter(adapter);

        loadUserData();
        loadWeightData();

        registerForContextMenu(weightListView);

        addWeightButton.setOnClickListener(v -> {
            finish();
        });

        // Request SMS permission if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    private void loadUserData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT username, goal_weight FROM users WHERE username = ?", new String[]{username});

        if (cursor.moveToFirst()) {
            String username = cursor.getString(0);
            goalWeight = cursor.getDouble(1);  // Fetch goal weight as double

            userNameTextView.setText(username != null ? "User: " + username : "User: Guest");
            goalWeightTextView.setText("Goal Weight: " + goalWeight + " lbs");
        } else {
            userNameTextView.setText("User: Guest");
            goalWeightTextView.setText("Goal Weight: Not Set");
        }

        cursor.close();
        db.close();
    }

    private void loadWeightData() {
        weightList.clear();
        entryIds.clear();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                "weights",
                new String[]{"id", "date", "weight"},
                "username = ?", new String[]{username}, null, null, "date DESC"
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                String weight = cursor.getString(2);

                entryIds.add(id);
                weightList.add(date + " - " + weight + " lbs");
            }
            cursor.close();
        }

        db.close();
        adapter.notifyDataSetChanged();
    }

    // Check if the weight meets or goes below the goal weight
    private void checkGoalAchievement(double weight) {
        if (weight <= goalWeight) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                sendGoalReachedSMS();
            } else {
                Toast.makeText(this, "Goal reached! SMS permission not granted.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void sendGoalReachedSMS() {
        String phoneNumber = "1234567890";  // Replace with actual user phone number
        String message = "Congratulations! You have reached your goal weight.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.weight_context_menu, menu);

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        if (entryIds.isEmpty() || info.position >= entryIds.size()) {
            selectedItemId = -1;
            return;
        }
        selectedItemId = entryIds.get(info.position);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_edit) {
            showEditDialog(selectedItemId);
            return true;
        } else if (item.getItemId() == R.id.menu_delete) {
            confirmDelete(selectedItemId);
            return true;
        }
        return super.onContextItemSelected(item);
    }

    private void showEditDialog(int itemId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry");

        final EditText inputWeight = new EditText(this);
        inputWeight.setHint("Enter new weight (lbs)");
        builder.setView(inputWeight);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newWeight = inputWeight.getText().toString().trim();
            if (!newWeight.isEmpty()) {
                updateWeight(itemId, newWeight);
            } else {
                Toast.makeText(this, "Weight cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void updateWeight(int itemId, String newWeight) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight", newWeight);

        int rows = db.update("weights", values, "id=?", new String[]{String.valueOf(itemId)});
        db.close();

        if (rows > 0) {
            Toast.makeText(this, "Weight updated!", Toast.LENGTH_SHORT).show();
            loadWeightData();
            checkGoalAchievement(Double.parseDouble(newWeight));  // Check goal after update
        }
    }

    private void confirmDelete(int itemId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage("Are you sure you want to delete this entry?")
                .setPositiveButton("Yes", (dialog, which) -> deleteWeight(itemId))
                .setNegativeButton("No", null)
                .show();
    }

    private void deleteWeight(int itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rows = db.delete("weights", "id=?", new String[]{String.valueOf(itemId)});
        db.close();

        if (rows > 0) {
            Toast.makeText(this, "Weight entry deleted!", Toast.LENGTH_SHORT).show();
            loadWeightData();
        }
    }

    // Handle SMS permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

package com.example.cs360p2wt_amos_roland;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;

    private TextView permissionStatusTextView;
    private Button requestPermissionButton, sendSmsButton;
    private EditText phoneNumberEditText, customMessageEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        permissionStatusTextView = findViewById(R.id.permissionStatusTextView);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        sendSmsButton = findViewById(R.id.sendSmsButton);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        customMessageEditText = findViewById(R.id.customMessageEditText);

        updatePermissionStatus();

        requestPermissionButton.setOnClickListener(v -> {
            if (!SmsHelper.checkSmsPermission(this)) {
                SmsHelper.requestSmsPermission(this);
            } else {
                Toast.makeText(this, "Permission already granted!", Toast.LENGTH_SHORT).show();
            }
        });

        sendSmsButton.setOnClickListener(v -> {
            String phoneNumber = phoneNumberEditText.getText().toString().trim();
            String message = customMessageEditText.getText().toString().trim();

            if (TextUtils.isEmpty(phoneNumber)) {
                Toast.makeText(this, "Please enter a phone number!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(message)) {
                message = "Congrats! You've reached your goal weight!"; // Default message
            }

            if (SmsHelper.checkSmsPermission(this)) {
                SmsHelper.sendSms(this, phoneNumber, message);
            } else {
                Toast.makeText(this, "Permission required to send SMS", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updatePermissionStatus() {
        if (SmsHelper.checkSmsPermission(this)) {
            permissionStatusTextView.setText("✅ SMS Permission Granted");
            sendSmsButton.setEnabled(true);
        } else {
            permissionStatusTextView.setText("❌ SMS Permission Denied");
            sendSmsButton.setEnabled(false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            } else {
                Toast.makeText(this, "Permission Denied! SMS feature will not work.", Toast.LENGTH_LONG).show();
                updatePermissionStatus();
            }
        }
    }
}
